# Change Log
All notabale changes to the project that deviate from the plan.


## Pokedex/Pokemon - 3 Levels of Inheritance
The levels of inheritance were changed for the same of concise and coherent coding practise. Instead of using multi-level inheritance for the actual pokemon/items, it was instead change into assertion as it makes more practical sense. It also made much more sense to use 3 level of inhertiance for the menuing, So it goes Menu -> Pokedex -> Pokedex Entry. This is much more practical and the reusable functions and entry makes much more sense when displaying text and menus with SFML. 

## Items
Since there is already 3 levels of inheritance and the items were beginning to become very complicated because of the levels of management in the system e.g. Held items via assertion and items used in the menu etc.

## Enviroment/Aesthetics
A change was made from the original plan of hosting battles and engaing with opponents, it was turned into a simulation against various randomly spawning pokemon around the map, this is to better manage the time and resources provided to us.

## Added Music
A simple pokemon song from the original game will play on repeat as you play the game.